@extends('layouts.main')
@section('title', 'Folders')
@section('content')
@push('head')
    <style>
        .wrapper .page-wrap .main-content {
            padding: 70px 0px 10px 10px;
            margin-top: 0px;
        }
        .entity-select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background: #171719;
            color: white !important;
            border: none;
            border-radius: 0;
            border-bottom: 1px solid #ffffff;
            width: 300px;
            font-size: 15px;
            padding: 10px 40px 10px 20px;
            position: relative;
        }
        footer.footer {
            display: none;
        }
        .app-sidebar.colored {
            display: none;
        }
        .wrapper .header-top {
            padding-left: 10px;
        }
        button#navbar-fullscreen {
            display: none;
        }
        a.nav-link.bg-gray.ml-1 {
            display: none;
        }
        #editor {
            width: 100%;
            height: 58vh;
        }
        .bg-black{
            background-color: #000000 !important;
        }

        .border-none{
            border-radius: 0;
            border: none;
        }

        .h-0{
            height: 0px !important;
        }

        .card .card-header {
            border-bottom: none !important;
        }

        .card .chat-box .chat-list .chat-item.odd .chat-content .box{
            background: #343a40 !important; 
        }

        .card .chat-box .chat-list .chat-item .chat-content .box {
            padding: 10px;
            color: #ffffff;
            background: #000000;
            font-weight: 700;
        }

        .card .card-footer {
            border-top: unset !important;
        }
        .project-card-scroll{
            height: 78vh;
            overflow-y: scroll;
        }
        /* width */
        .project-card-scroll::-webkit-scrollbar {
           width: 2px;
        }
        .split {
            display: flex;
            flex-direction: row;
        }

        .gutter {
            background-color: #eee;
            background-repeat: no-repeat;
            background-position: 50%;
        }

        .gutter.gutter-horizontal {
            background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAeCAYAAADkftS9AAAAIklEQVQoU2M4c+bMfxAGAgYYmwGrIIiDjrELjpo5aiZeMwF+yNnOs5KSvgAAAABJRU5ErkJggg==');
            cursor: col-resize;
            width: 3px !important;
        }
    </style>
      <style>
        body, html { height: 100%; margin: 0; overflow: hidden; }
        #split-0, #split-1 { height: 100%; }
        #editor { width: 100%; height: 100%; }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.33.0/min/vs/loader.min.js"></script>
@endpush
<div class="container-fluid">
    <div class="row mt-10 split">

        <div id="split-0" style="width: calc(22.8614% - 10px);">
            <div class="card mb-0">
                <div class="card-header d-flex justify-content-between py-0 px-2 bg-black" style="border-bottom: 1px solid #ccc !important">
                    <div> 
                        <i class="fa fa-search text-muted"></i>
                    </div>
                    <input class="form-control fw-700 bg-black border-none " type="text" name=""
                        placeholder="Search File" id="file-search"
                        oninput="fileSearch()">
                    <div class="d-flex">
                        <!-- <a target="_blank" title="Download File" href="{{ route('panel.admin.projects.download-file',['dir' => $projectEntity->name])}}" class="btn btn-dark btn-icon text-white ml-1">
                            <i class="fas fa-download"></i>
                        </a> -->
                    </div>
                </div>
                
                <div class="card-body border-none px-0 pl-1 bg-black project-card-scroll">
                    <div id="search-file-navigation" class="navigation-main">
                    </div>
                    <div id="main-file-navigation">
                        @include('panel.admin.code-register.playground.includes.directory-list',['projectEntity' => $projectEntity])
                    </div>
                </div>
            </div>
        </div>

        
        <div id="split-1" style="width: calc(55.0147% - 10px);">
            <div id="loader_container">
                <div class="loader-img-position" style="top: 30vh; position: relative;left: 50%;">
                    <div class="text-white">
                        <img src="{{ asset('panel/admin/default/loading.gif') }}" alt=""style="width: 55px;filter:invert(1)">
                    </div>
                </div>
            </div>

            @include('panel.admin.code-register.playground.includes.file-content')
        </div>
        <div id="split-2" style="width: calc(22.1239% + 0px);">
            @include('panel.admin.code-register.playground.includes.assistant')
        </div>
    </div>
</div>
<!-- push external js -->
@push('script')
    @include('panel.admin.code-register.playground.includes.script')
@endpush
@endsection