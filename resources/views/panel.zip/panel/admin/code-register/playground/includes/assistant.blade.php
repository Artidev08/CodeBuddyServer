<div class="card mb-0 bg-black">
    <div class="card-header text-white d-flex justify-content-start pt-3 pb-3">
        <img style="width: 30px; object-fit: contain; filter: invert(1);" src="{{ getBackendLogo(getSetting('app_favicon', @$setting)) }}" alt="" class="mr-2">
        <h6 class="mb-0 fw-800">Ai Assistant</h6>
    </div>
    <div class="card-body chat-box " style="height: 69vh;overflow: auto;">
        <div class="d-flex justify-content-center mt-30" id="blank_message">
            <div class="">
                <div class="text-white" style="margin-top: 25vh">
                    <h6 class="text-white">Namaste! Ask Help Here...</h6>
                </div>
               
            </div>
        </div>
        <div>
            <ul class="chat-list">
            </ul>
        </div>
    </div>
    <div class="card-footer p-1">
        <div class="d-flex justify-content-between pb-1" id="message_area">
            <input type="text" name="content" id="content" class="bg-black border-none text-white fw-700 form-control mr-1" placeholder="Enter Your Message Here" style="border-bottom: 1px solid #ccc">
            <div class="mr-2">
                <button id="send" type="button" class="btn btn-icon btn-dark text-white mt-1 p-0 chat-box-send">
                    <i class="fa-solid fa-arrow-up"></i>
                </button>
            </div>
        </div>
    </div>
</div>