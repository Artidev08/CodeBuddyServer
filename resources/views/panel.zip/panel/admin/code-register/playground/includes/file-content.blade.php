<div class="card mb-0 bg-black border-none" id="data_container" style="display: none;">
    <div class="card-header pb-1 pt-2 d-flex justify-content-between">
        <div class="pb-2">
            <div class="d-flex">
                <h3 id="chat-user" class="mb-0 text-white fw-800" style=" color: white !important; font-size:14px;">
                    {{ $projectEntity->module }} - {{ $projectEntity->title }}</h3>
            </div>
            <div class="fw-700" style="color: #a4aeb6 !important;">
                <span id="file_name" style="display: none;"> {{ $projectEntity->module }} - {{ $projectEntity->group }} </span>
            </div>
        </div>
    </div>
    <div id="group_chat_list">
        <div class="card-body chat-box pt-0">
            <input type="hidden" name="file_path" id="file_path">
          
            <textarea name="editor_content" id="editor_content" rows="18" cols="18" readonly class="form-control bg-dark" style="height: 70vh;"></textarea>
            <textarea name="file_content" id="file_content" rows="18" cols="18" class="form-control d-none" style="height: 58vh;"></textarea>
            <div class="d-flex justify-content-between mt-2">
                <div class="mt-5 fw-700">
                    <span class="text-muted d-none" title="Characters Count">Characters: <span class="fw-700" id="proceeded_char_count">0</span></span>
                    <span class="text-muted ml-5 d-none" title="Words Count">| Words: <span class="fw-700" id="proceeded_word_count">0</span></span>                    
                </div>
                <div>
                    <span class="text-muted ml-5" title="Last Updated At"> <i class="fa fa-clock"></i> <span class="fw-700" id="">{{$projectEntity->updated_at->diffForHumans()}}</span></span>
                </div>
            </div>
        </div>
    </div>
</div>