<ul class="text-muted list-unstyled">
    @foreach ($files as $key => $file)
        <li class="fw-800">
            <ul class="list-unstyled ml-2">
                <li class="mb-1 fw-800 ml-2">
                    <a title="{{$file->file_name}}" href="javascript:void(0)" onclick="getDirContent({{ json_encode($file->path) }})" class="text-white fw-700 " data-toggle="tooltip">
                        {{ $file->file_name }} ( {{ $file->group }})
                    </a>
                </li>
                @if ($key == 0)
                    <input type="hidden" name="main_dir"  id="main_dir" value="{{ $file->path }}">
                @endif
            </ul>
        </li>
    @endforeach
</ul>