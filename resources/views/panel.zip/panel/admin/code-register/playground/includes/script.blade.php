<script>
    // $(document).ready(function() {
    //     setTimeout(() => {
    //         $('.editor-load').addClass('d-none');
    //         $('#split-1').removeClass('d-none');
    //         $('#split-2').removeClass('d-none');
    //     }, 1000);
    // });

    let editor;

    $(document).ready(function() {

        // Initialize Split.js
        Split(['#split-0', '#split-1', '#split-2'], {
            sizes: [15, 75, 10], // Adjust sizes as needed
            minSize: 300,
            gutterAlign: 'start',
            onDrag: function() {
                // Trigger Monaco editor layout update
                if (editor) {
                    editor.layout();
                }
            }
        });

        // Load Monaco Editor
        require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.33.0/min/vs' } });
        require(['vs/editor/editor.main'], function() {
            monaco.editor.defineTheme('default', {
                base: 'vs-dark',
                inherit: true,
                rules: [
                    { token: "identifier", foreground: "9CDCFE" },
                    { token: "identifier.function", foreground: "DCDCAA" },
                    { token: "type", foreground: "1AAFB0" }
                ],
                colors: {}
            });
            monaco.editor.setTheme('default');

            // Create the Monaco editor in the designated element
            editor = monaco.editor.create(document.getElementById('editor'), {
                value: '',
                language: 'php'
            });

            // Add content change listener
            editor.onDidChangeModelContent(updateCounts);

            function updateCounts() {
                const content = $('#editor_content').val();
                const charCount = content.length;
                const words = content.split(/\s+/).filter(word => word.length > 0);
                const wordCount = words.length;
                document.getElementById('proceeded_char_count').textContent = charCount;
                document.getElementById('proceeded_word_count').textContent = wordCount;
            }
        });
    });
</script>
<script>
    const apiKey = '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';
   
    $('#entity').on('change', function(){
        var id = $('#entity').val();
        var url = id; // Corrected URL
        window.location.href = url;
    });
    setTimeout(() => {
        var main_dir = $('#main_dir').val();
        getDirContent(main_dir);
    }, 1000);
    
    $('#file_content').on('input', function() {
        const content = $(this).val();
        const charCount = content.length;
        const words = content.split(/\s+/).filter(word => word.length > 0);
        const wordCount = words.length;
        $('#proceeded_char_count').text(charCount);
        $('#proceeded_word_count').text(wordCount);
    });
    $(document).ready(function() {
        setTimeout(() => {
            $('#content').focus();
            setTimeout(() => {
                $('#content').attr('placeholder', 'I am ready!');
                setTimeout(() => {
                    $('#content').attr('placeholder',
                        'Give me instructions to help you');
                }, 2000);
            }, 1000);
        }, 500);
    });

    // Function to get directory content and display in the editor
    function getDirContent(mainDirName) {
        $('#loader_container').show();
        $('#data_container').hide();

        const url = `/admin/projects/get-file-content?dir=${mainDirName}`;
        fetch(url)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else {
                    // Display the file content in Monaco Editor
                    $('#file_name').show();
                    document.getElementById('file_name').textContent = `${mainDirName}`;
                    document.getElementById('file_path').value = `${mainDirName}`;
                    $('#editor_content').val(data.content);  
                    $('#updated_at').text(data.updated_at);
                    const downloadPath = `/admin/projects/download-file?dir=${encodeURIComponent(mainDirName)}`;
                    document.getElementById('download_file').setAttribute('href', downloadPath);
                    updateCounts();
                }
            })
            .catch(error => console.error('Error fetching file content:', error))
            .finally(() => {
                setTimeout(() => {
                    $('#loader_container').hide();
                    $('#data_container').show();
                }, 500);
            });
            
    }

    // Function to copy content from Monaco Editor to clipboard
    function copyFileContent() {
        const copiedText = $('#editor_content').val();  // Get the content from Monaco Editor
        const copyIcon = document.getElementById('copyFileContent');
        navigator.clipboard.writeText(copiedText).then(function() {

            // Reduce opacity of the icon
            copyIcon.style.opacity = '0.5'; // Adjust opacity as needed

            // Reset opacity after a delay (e.g., 2 seconds)
            setTimeout(() => {
                copyIcon.style.opacity = '1';
            }, 1000); // Adjust timing as needed
        }).catch(function(err) {
            console.error('Failed to copy text: ', err);
        });
    }
    // Function to save content of file
    $('#save_file').on('click',function(e) {
        var file_path = $('#file_path').val();
        var file_content = $('#editor_content').val();
        if(file_path == ''){
            pushNotification('Error', 'Please Select File', 'error');
            return false;
        }
        if(file_content == ''){
            pushNotification('Error', 'Please Enter Content', 'error');
            return false;
        }
        $('#save_file').css('opacity', 0.5);

        url = "{{ route('panel.admin.projects.save-file')}}";
        $.ajax({
            type: 'POST',
            url: url,
            data: {
                file_content: file_content,
                file_path: file_path
            },
            success: function(resultData) {
                console.log(resultData);
            
                $('#save_file').css('opacity', 1);
                $('#updated_at').text(data.updated_at); //
            },
            error: function(error) {
                pushNotification('Error', error.error, 'error');
            }
        });
    });

    // Function to search files in sidebar
    function fileSearch() {
        var filter, item;
        filter = $("#file-search").val().trim().toLowerCase();
        items = $("#main-file-navigation").find("a");
        items = items.filter(function (i, item) {
            if ($(item).html().trim().toLowerCase().indexOf(filter) > -1 && $(item).attr('href') !== '#') {
                return item;
            }
        });
        if (filter !== '') {
            $("#main-file-navigation").addClass('d-none');
            $("#search-file-navigation").html('')
            if (items.length > 0) {
                for (i = 0; i < items.length; i++) {
                    const text = $(items)[i].innerText;
                    const link = $(items[i]).attr('href');
                    const onclick = $(items[i]).attr('onclick');
                    $("#search-file-navigation").append(
                        `<li><a href="${link}" onclick="${onclick}" class="btn btn-link fw-900 p-1" >${text}</a></li>`
                    );
                }
            } else {
                $("#search-file-navigation").html(
                    `<div class="nav-item"><span class="text-center text-muted d-block">No File Found</span></div>`
                );
            }
        } else {
            $("#main-file-navigation").removeClass('d-none');
            $("#search-file-navigation").html('')
        }
    }


    //start script for assistant
    $('#send').on('click', async function(e) {
        var content = $('#content').val();
        if (content == "") {
            pushNotification('error', 'Please enter content', 'error');
            return false;
        } else {
            // Preparation steps before regeneration or initial generation
            $('#blank_message').removeClass('d-flex').addClass('d-none');
            $('.chat-list').show();
            $('#content').val('');
            $('#send').prop('disabled', true);
            $('#content').css('pointer-events', 'none');
            $('#content').css('background', 'aliceblue');
            $('#send').html('<i class="fa fa-spinner fa-spin"></i>');
            appendElement('chat-item', content, 'user');

            // Start the chat sequence with the given content
            await chatSequence(content);
        }
    });
    function appendElement(chat_list, message, by, bg_light = null) {

        new_chat_list = chat_list;
        if(by == 'user'){
            new_chat_list = chat_list+' odd';
        }
        var newListItem = $('<li class="' + new_chat_list + ' mt-1">' +
                '<div class="chat-content ' + bg_light + '">' +
                    '<div class="box bg-light-info">' + message + '</div>' +
                '</div>' +
            '</li>');
        $('.chat-list').append(newListItem);
        $('.chat-box').scrollTop($('.chat-box')[0].scrollHeight);
    }
    $('.chat-box').scrollTop($('.chat-box')[0].scrollHeight);
    
   
    async function chatSequence(content) {
        appendElement('chat-item', 'Typing...', 'assistant', 'bg_light');
        var data = {
            model: "gpt-3.5-turbo",
            messages: [{ role: "user", content: content }],
            stream: true, // Enable streaming
        };

        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        if (!response.body) {
            pushNotification('error', 'ReadableStream not supported');
            return;
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let text = '';
        let typingElement = $('.chat-item:contains("Typing...")').last();

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value);
            const lines = chunk.split('\n');
            for (let line of lines) {
                if (line.trim() === '') continue;
                if (line.trim() === 'data: [DONE]') {
                    typingElement.remove();
                    appendElement('chat-item', text, 'assistant', 'bg_light');
                    $('#content').css('pointer-events', 'auto');
                    $('#content').css('background', 'white');
                    $('#send').prop('disabled', false);
                    $('#send').html('<i class="fa fa-paper-plane"></i>');
                    return;
                }

                try {
                    const json = JSON.parse(line.replace(/^data: /, ''));
                    const delta = json.choices[0].delta;
                    if (delta.content) {
                        text += delta.content;
                        typingElement.find('.chat-content .box').html(text.replace(/\n/g, '<br>'));
                        $('.chat-box').scrollTop($('.chat-box')[0].scrollHeight);
                    }
                } catch (error) {
                    console.error('Error parsing line:', line, error);
                }
            }
        }
    }
    //end script for assistant

</script>