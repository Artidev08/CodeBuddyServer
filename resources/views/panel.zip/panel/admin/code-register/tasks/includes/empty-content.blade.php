<div class="loader-img-position" style="top: 30vh; position: relative;left: {{ $leftMargin ?? '50' }}%;">
    <div class="text-white">
        <img src="{{ asset('panel/admin/default/loading.gif') }}" alt="" style="width: 55px;filter:invert(1)">
    </div>
</div>