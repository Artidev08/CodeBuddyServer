@if($agents->count() > 0)
    <ul class="text-muted list-unstyled" id="agent_container">
        @foreach ($agents as $agent_key => $agent)
            @php 
                $completedLogCount = getAgentCompletedLogCount($agent);
                $totalLogCount = $agent->codeRegisterAgentLogs->count();
                $progressPercentage = $totalLogCount > 0 ? ($completedLogCount / $totalLogCount) * 100 : 0;
            @endphp
            <form id="agent-form-{{ $agent_key }}" onsubmit="sendFilesToGPT(event, {{ $agent->id }})">
                <input type="hidden" name="code_register_id" value="{{ $projectEntity->id }}" id="">
                <input type="hidden" name="agent_id" value="{{ $agent->id }}" id="">
                <input type="hidden" name="project_id" value="{{ $projectEntity->project->id }}" id="">
                <li id="agent-item-{{ $agent->id }}" class="border-{{ @App\Models\CodeRegisterAgent::STATUSES[$agent->status]['color'] }} agent-item fw-800 mb-1 @if($agent_key == 0) selected @endif ">
                    <div class="d-flex justify-content-between pb-2">
                        <div>
                            <a title="{{ $agent->name }}" href="javascript:void(0)"
                                class="text-white fw-700 agent-name"
                                data-agent-id="{{ $agent->id }}"
                                data-register-id="{{ $projectEntity->id }}"
                                data-toggle="tooltip">
                                {{ Str::limit($agent->name,50) }} ({{$agent->getPrefix()}})
                                <!-- <span id="status_{{$agent->id}}" class="text-{{ @App\Models\CodeRegisterAgent::STATUSES[$agent->status]['color'] }} ml-1 fs-15 fw-800">
                                    {{ @App\Models\CodeRegisterAgent::STATUSES[$agent->status]['label'] }}
                                </span> -->
                                <div class="progress-bar-container">
                                    <div class="progress-bar" style="width: {{ $progressPercentage }}%;">
                                        <span class="progress-text">{{ $completedLogCount }} / {{ $totalLogCount }}</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                        @if($agent->status != App\Models\CodeRegisterAgent::STATUS_CLOSED)
                        <button type="submit" class="btn btn-link w-10 submit-btn mr-2 p-0">
                            <i class="ik ik-play"></i>
                        </button>
                        @endif
                    </div>
                    <div class="card bg-dark text-white mb-2 d-none">
                        @if($agent->codeRegisterAgentLogs->count() > 0)
                        <div class="d-flex justify-content-between p-2">
                            <span class="text-{{ @App\Models\CodeRegisterAgent::STATUSES[$agent->status]['color'] }} ml-1 fs-15 fw-800">
                                {{ @App\Models\CodeRegisterAgent::STATUSES[$agent->status]['label'] }}
                            </span>
                            <p class="mb-0">
                                <a target="_blank" href="{{ route('panel.admin.code-register.playground',$projectEntity->id)}}?agent_id={{ $agent->id }}" class="btn btn-secondary">
                                    Logs <i class="ik ik-external"></i>
                                </a>
                            </p>
                        </div>
                        @endif
                        <div class="card-body p-2">
                            @if($agent->scope_ids && is_array($agent->scope_ids))
                            <p class="mb-1">
                                Scopes:
                                @foreach($agent->scope_ids as $scope_key => $scope_access_id)
                                    {{ $scope_access_id }}@if(!$loop->last), @endif
                                @endforeach
                            </p>
                            @endif
                            @if($agent->gpt_code)
                            <p class="mb-1">GPT Code: {{ $agent->gpt_code }}</p>
                            @endif
                            @if($agent->model)
                            <p class="mb-1">Model: {{ $agent->model ? $agent->model->name : '' }}</p>
                            <p class="mb-1">Thread: {{ $agent->thread_id ?? '' }}</p>
                            @endif
                            <textarea name="prompt" id="prompt-{{ $agent_key }}" class="form-control mt-2"
                                @if($agent->status != App\Models\CodeRegisterAgent::STATUS_NOT_STARTED)
                                readonly @endif rows="18">{{ $agent->prompt }}</textarea>
                        </div>
                    </div>
                </li>
            </form>
        @endforeach
    </ul>
@else
    @include('panel.admin.code-register.tasks.includes.empty-content', ['leftMargin' => '40'])
@endif
