@if($agentData != null)
<div id="log-container">
    <div class="accordion" id="agentDetailsAccordion">
        <div class="card mb-1">
            <div class="card-header p-2 d-flex justify-content-between" id="headingOne">
                <h2 class="mb-0">
                    <button class="btn btn-link text-white w-100 text-left fs-15 d-flex justify-content-between align-items-center" 
                            type="button" 
                            data-toggle="collapse" 
                            data-target="#collapseOne" 
                            aria-expanded="true" 
                            aria-controls="collapseOne">
                        
                        <span>{{ $agentData->name ?? '--' }}</span>
                    </button>
                </h2>
                
                <!-- Progress Bar Moved Outside Button for Proper Styling -->
                <div class="d-flex align-items-center">
                    @if($agentData->approvedCodeRegisterAgentLog)
                        <div class="dropdown mr-2">
                            <button class="dropdown-toggle btn btn-secondary" type="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Action
                                <i class="ik ik-chevron-right p-0 m-0"></i>
                            </button>
                            <ul class="dropdown-menu multi-level" role="menu" aria-labelledby="dropdownMenu">
                                <li class="dropdown-item">
                                    <a href="{{ route('panel.admin.code-register.merge-code', secureToken($agentData->id)) }}" class="confirm" data-msg="You wanted to Merge & Push all approved files codes."><i class="ik ik-git-merge mr-2"> </i>Merge & Push
                                </li></a>
                            </ul>
                        </div>
                    @endif
                    <div class="progress-bar-container mt-1">
                        <div class="progress-bar" style="width: {{ $progressPercentage }}%;">
                            <span class="progress-text">{{ $completedLogCount }} / {{ $totalLogCount }}</span>
                        </div>
                    </div>
                    <i class="fa fa-chevron-down ml-2" id="accordionIcon"></i>
                </div>
            </div>

            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#agentDetailsAccordion">
                <div class="card-body bg-dark text-white" style="height: 40vh; overflow: auto;">
                    <p class="mb-1">
                        Scopes:
                        @foreach($agentData->scope_ids as $scope_key => $scope_access_id)
                            {{ $scope_access_id }}@if(!$loop->last), @endif
                        @endforeach
                    </p>
                    <p class="mb-1"><strong>Model:</strong> {{ $agentData->model->name }}</p>
                    @if($agentData->thread_id)
                        <p class="mb-1"><strong>Thread:</strong> {{ $agentData->thread_id }}</p>
                    @endif
                    <p class="mb-1"><strong>GPT Code:</strong> {{ $agentData->gpt_code }}</p>
                    <p class="mb-1"><strong>Prompt:</strong></p>
                    <p class="mb-1">{!! nl2br($agentData->prompt) !!}</p>
                    @if($agentData->input_content)
                        <p class="mb-1"><strong>Input Content:</strong></p>
                        <p class="mb-1"> {!! nl2br($agentData->input_content) !!}</p>
                    @endif
                    @if($agentData->output_content)
                        <p class="mb-1"><strong>Output Content:</strong></p>
                        <p class="mb-1"> {!! nl2br($agentData->output_content) !!}</p>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <ul class="text-muted list-unstyled">
        @if($agentLogs->count() > 0)
            <div class="d-flex overflow-auto align-items-center" style="white-space: nowrap; overflow: auto;">
                <ul class="nav nav-tabs flex-nowrap" id="logTabs" role="tablist" style="display: flex;">
                    @foreach ($agentLogs as $file_key => $file)
                        <li class="nav-item" role="presentation">
                            <a title="{{ $file->getPrefix() }}" class="p-1 nav-link text-white @if($loop->first) active @endif" id="tab-{{ $file_key }}" data-toggle="tab" href="#log-content-{{ $file_key }}" role="tab" aria-controls="log-content-{{ $file_key }}" aria-selected="true">
                                {{ Str::limit(basename($file->path),30)}}
                                <span class="text-{{ @App\Models\CodeRegisterAgentLog::STATUSES[$file->status]['color'] }} ml-1 fw-800">
                                    ({{ @App\Models\CodeRegisterAgentLog::STATUSES[$file->status]['label'] }})
                                </span>
                            </a>
                        </li>
                    @endforeach
                </ul>
            </div>

            <div class="tab-content mt-1" id="logTabContent" style="max-height: 70vh; overflow: auto;">
                @foreach ($agentLogs as $log_key => $file)
                    <div class="tab-pane fade @if($loop->first) show active @endif" id="log-content-{{ $log_key }}" role="tabpanel" aria-labelledby="tab-{{ $log_key }}">
                        <div class="card bg-dark text-white mb-2">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-6">
                                        <div class="card-body p-0">
                                            <div class="d-flex justify-content-between">
                                                Input ({{ basename($file->path)}})
                                                <div>
                                                    <a href="javascript:void(0)" onclick="copyFileContent('input-prompt-{{ $log_key }}')" class="btn btn-link text-white p-0">
                                                        <i class="fa fa-copy"></i>
                                                    </a>
                                                </div>
                                            </div>
                                            {{-- <div id="editor-{{ $log_key }}" class="monaco-editor-container" style="width:100%; height:400px; border:1px solid #ddd;"></div>  --}}
                                            <div id="input-editor-{{ $log_key }}" class="p-0 editor-container mt-2" style="height: 45vh;"></div>
                                            <textarea id="input-prompt-{{ $log_key }}" class="form-control mt-2 input-prompt d-none" rows="16" readonly>{{ $file->input_content }}</textarea>
                                            {{-- <textarea id="input-prompt-{{ $log_key }}" class="form-control mt-2 input-prompt" rows="16" readonly>{{ $file->input_content }}</textarea> --}}
                                        </div>
                                        <div class="justify-content-between mt-2">
                                            <div class="mt-5 fw-700">
                                                <span class="text-muted" title="Characters Count">Characters: <span class="fw-700" id="input_char_count">{{ strlen($file->input_content) }}</span></span>
                                                <span class="text-muted ml-5" title="Words Count">| Words: <span class="fw-700" id="input_word_count">{{ str_word_count($file->input_content) }}</span></span>                    
                                            </div>
                                        </div>
                                    </div>
                                    @if($file->output_content)
                                        <div class="col-6">
                                            <div class="card-body p-0">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        Output
                                                    </div>
                                                    <div class="d-flex">
                                                        @if($file->status == App\Models\CodeRegisterAgentLog::STATUS_COMPLETED || $file->status == App\Models\CodeRegisterAgentLog::STATUS_APPROVED || $file->status == App\Models\CodeRegisterAgentLog::STATUS_REJECT)
                                                            <select name="status" id="status" class="form-control" data-id="{{ $file->id }}">
                                                                <option readonly>Select Status</option>
                                                                <option value="{{ App\Models\CodeRegisterAgentLog::STATUS_APPROVED }}" @if($file->status == App\Models\CodeRegisterAgentLog::STATUS_APPROVED) selected @endif>Accept</option>
                                                                <option value="{{ App\Models\CodeRegisterAgentLog::STATUS_REJECT }}" @if($file->status == App\Models\CodeRegisterAgentLog::STATUS_REJECT) selected @endif>Reject</option>
                                                            </select>
                                                        @endif
                                                        <a href="javascript:void(0)" onclick="copyFileContent('output-prompt-{{ $log_key }}')" class="btn btn-link text-white px-1 py-1 ml-1">
                                                            <i class="fa fa-copy"></i>
                                                        </a>
                                                        <a href="javascript:void(0)" onclick="saveFileContent('{{ $log_key }}')" class="btn btn-link text-white px-1 py-1">
                                                            <i class="fa fa-save"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="output-path-{{ $log_key }}" id="output-path-{{ $log_key }}" value="{{ $file->path }}">
                                                <div id="output-editor-{{ $log_key }}" class="p-0 editor-container mt-2" style="height: 45vh;"></div>
                                                <textarea id="output-prompt-{{ $log_key }}" class="form-control mt-1 output-prompt d-none" rows="16">{{ removeCodeBlockTags($file->output_content) }}</textarea>
                                            </div>
                                            <div class="justify-content-between mt-2">
                                                <div class="mt-5 fw-700">
                                                    <span class="text-muted" title="Characters Count">Characters: <span class="fw-700" id="output_char_count">{{ strlen($file->output_content) }}</span></span>
                                                    <span class="text-muted ml-5" title="Words Count">| Words: <span class="fw-700" id="output_word_count">{{ str_word_count($file->output_content)  }}</span></span>                    
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @else
            <div class="loader-img-position" style="top: 30vh; position: relative;left: 50%;">
                <div class="text-white">
                    <img src="{{ asset('panel/admin/default/loading.gif') }}" alt="" style="width: 55px;filter:invert(1)">
                </div>
                <p>No Logs!</p>
            </div>
        @endif
    </ul>
</div>
@else
    @include('panel.admin.code-register.tasks.includes.empty-content')
@endif