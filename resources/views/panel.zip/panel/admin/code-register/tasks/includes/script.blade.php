<script>
    function initilizedEditor(logKey) {
        require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.33.0/min/vs' } });
        require(['vs/editor/editor.main'], function () {
            monaco.editor.defineTheme('default', {
                base: 'vs-dark',
                inherit: true,
                rules: [
                    { token: "identifier", foreground: "9CDCFE" },
                    { token: "identifier.function", foreground: "DCDCAA" },
                    { token: "type", foreground: "1AAFB0" }
                ],
                colors: {}
            });
            monaco.editor.setTheme('default');

            // Select input and output editor containers
            let inputEditorContainer = document.getElementById(`input-editor-${logKey}`);
            let outputEditorContainer = document.getElementById(`output-editor-${logKey}`);

            if (!inputEditorContainer || !outputEditorContainer) return; // Prevent errors if editor container doesn't exist

            // Get content for input and output editors
            let inputContent = $(`#input-prompt-${logKey}`).val() || ''; 
            let outputContent = $(`#output-prompt-${logKey}`).val() || ''; 

            // Destroy existing editors before creating new ones
            if (inputEditorContainer.monacoEditor) {
                inputEditorContainer.monacoEditor.dispose();
            }
            if (outputEditorContainer.monacoEditor) {
                outputEditorContainer.monacoEditor.dispose();
            }

            // Initialize Monaco Editor for input
            let inputEditor = monaco.editor.create(inputEditorContainer, {
                value: inputContent,
                language: 'php',
                theme: 'vs-dark'
            });
            inputEditorContainer.monacoEditor = inputEditor;

            // Initialize Monaco Editor for output
            let outputEditor = monaco.editor.create(outputEditorContainer, {
                value: outputContent,
                language: 'php',
                theme: 'vs-dark'
            });
            outputEditorContainer.monacoEditor = outputEditor;

            // Update word and character counts when content changes
            inputEditor.onDidChangeModelContent(() => updateCounts(inputEditor, logKey, 'input'));
            outputEditor.onDidChangeModelContent(() => updateCounts(outputEditor, logKey, 'output'));
        });
    }

    function updateCounts(editor, logKey, type) {
        const content = editor.getValue();
        const charCount = content.length;
        const words = content.split(/\s+/).filter(word => word.length > 0);
        const wordCount = words.length;

        $(`#${type}-char_count-${logKey}`).text(charCount);
        $(`#${type}-word_count-${logKey}`).text(wordCount);
    }

    // When a new tab is shown, initialize Monaco Editor for that tab
    $(document).on('shown.bs.tab', 'a[data-toggle="tab"]', function (e) {
        let logKey = $(e.target).attr('href').split('-').pop(); // Extract log key from href
        setTimeout(() => initilizedEditor(logKey), 100); // Delay to allow tab rendering
    });

    $(document).ready(function () {
        Split(['#split-0', '#split-1'], {
            sizes: [25, 75],
            minSize: 300,
            gutterAlign: 'start'
        });

        // Initialize editor for the first active tab
        let firstActiveTab = $('.tab-pane.show.active').attr('id');
        if (firstActiveTab) {
            let logKey = firstActiveTab.split('-').pop();
            initilizedEditor(logKey);
        }
    });
</script>

<script>
    function showDifferences(logKey) {
        const inputText = document.getElementById(`input-prompt-${logKey}`).value;
        const outputText = document.getElementById(`output-prompt-${logKey}`).innerText;

        const inputLines = inputText.split('\n');
        const outputLines = outputText.split('\n');

        let diffContent = ''; // This will hold the final HTML content for the output

        const maxLength = Math.max(inputLines.length, outputLines.length);

        for (let i = 0; i < maxLength; i++) {
            const inputLine = inputLines[i] || '';
            const outputLine = outputLines[i] || '';

            if (inputLine !== outputLine) {
                if (outputLine) {
                    // New line added in output
                    diffContent += `<span class="added">${outputLine}</span><br>`;
                }
                if (inputLine) {
                    // Line removed from input
                    diffContent += `<span class="removed">${inputLine}</span><br>`;
                }
            } else {
                // Lines are the same
                diffContent += `${inputLine}<br>`;
            }
        }

        // Update the content of the output div with the differences
        document.getElementById(`output-prompt-${logKey}`).innerHTML = diffContent;
    }
</script>
<script>
    const apiKey = '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';
   
    $('#entity').on('change', function(){
        var id = $('#entity').val();
        var url = id; // Corrected URL
        window.location.href = url;
    });
    
    $('#file_content').on('input', function() {
        const content = $(this).val();
        const charCount = content.length;
        const words = content.split(/\s+/).filter(word => word.length > 0);
        const wordCount = words.length;
        $('#proceeded_char_count').text(charCount);
        $('#proceeded_word_count').text(wordCount);
    });
    $(document).ready(function() {
        setTimeout(() => {
            $('#content').focus();
            setTimeout(() => {
                $('#content').attr('placeholder', 'I am ready!');
                setTimeout(() => {
                    $('#content').attr('placeholder',
                        'Give me instructions to help you');
                }, 2000);
            }, 1000);
        }, 500);
    });

    // Function to copy content from Monaco Editor to clipboard
    function copyFileContent(elementId) {
        const copiedText = document.getElementById(elementId).innerText || document.getElementById(elementId).value;
        const copyIcon = document.getElementById('copyFileContent-' + elementId);

        navigator.clipboard.writeText(copiedText).then(function() {
            // Reduce opacity of the icon
            copyIcon.style.opacity = '0.5';

            // Reset opacity after a delay (e.g., 2 seconds)
            setTimeout(() => {
                copyIcon.style.opacity = '1';
            }, 1000);
        }).catch(function(err) {
            console.error('Failed to copy text: ', err);
        });
    }
    // Function to save content of file
    function saveFileContent(key) {
        var file_path = $('#output-path-' +key).val();
        var file_content = $('#output-prompt-' +key).val();
        if(file_path == ''){
            pushNotification('Error', 'Please Select File', 'error');
            return false;
        }
        if(file_content == ''){
            pushNotification('Error', 'Please Enter Content', 'error');
            return false;
        }
        $('#save_file-' +key).css('opacity', 0.5);

        url = "{{ route('panel.admin.projects.save-file')}}";
        $.ajax({
            type: 'POST',
            url: url,
            data: {
                file_content: file_content,
                file_path: file_path
            },
            success: function(resultData) {
                console.log(resultData);
                $('#save_file-' +key).css('opacity', 1);
                $('#updated_at').text(resultData.updated_at); //
            },
            error: function(error) {
                pushNotification('Error', error.error, 'error');
            }
        });
    }

    // Function to search files in sidebar
    function fileSearch() {
        var filter, item;
        filter = $("#file-search").val().trim().toLowerCase();
        items = $("#main-file-navigation").find("a");
        items = items.filter(function (i, item) {
            if ($(item).html().trim().toLowerCase().indexOf(filter) > -1 && $(item).attr('href') !== '#') {
                return item;
            }
        });
        if (filter !== '') {
            $("#main-file-navigation").addClass('d-none');
            $("#search-file-navigation").html('')
            if (items.length > 0) {
                for (i = 0; i < items.length; i++) {
                    const text = $(items)[i].innerText;
                    const link = $(items[i]).attr('href');
                    const onclick = $(items[i]).attr('onclick');
                    $("#search-file-navigation").append(
                        `<li><a href="${link}" onclick="${onclick}" class="btn btn-link fw-900 p-1" >${text}</a></li>`
                    );
                }
            } else {
                $("#search-file-navigation").html(
                    `<div class="nav-item"><span class="text-center text-muted d-block">No File Found</span></div>`
                );
            }
        } else {
            $("#main-file-navigation").removeClass('d-none');
            $("#search-file-navigation").html('')
        }
    }
</script>

<script>
   
    var stopSubmission = false; // Flag to control stopping the submission

    $('#start-project-btn').on('click', function() {
        var confirmStart = confirm($(this).data('msg')); // Show confirmation message
        if (!confirmStart) return; // Exit if user cancels

        var agentForms = $('form[id^="agent-form-"]'); // Select all the agent forms
        var currentIndex = 0;
        stopSubmission = false; // Reset stop flag

        // Hide Start button and show Stop button
        $('#start-project-btn').hide();
        $('#stop-project-btn').show();

        // Function to trigger submit button click one by one
        function submitNextForm() {
            if (stopSubmission) {
                console.log("Submission stopped.");
                $('#start-project-btn').show(); // Show Start button
                $('#stop-project-btn').hide(); // Hide Stop button
                return; // Exit if stopSubmission is true
            }

            if (currentIndex < agentForms.length) {
                var form = agentForms[currentIndex];
                var submitButton = $(form).find("button[type='submit']");

                // Trigger the submit button click event
                submitButton.click(); 

                currentIndex++; // Move to the next form
                setTimeout(submitNextForm, 2000); // Wait for 2 seconds before submitting the next one
            } else {
                console.log("All forms have been submitted.");
                $('#start-project-btn').show(); // Show Start button
                $('#stop-project-btn').hide(); // Hide Stop button
            }
        }

        submitNextForm(); // Start the process
    });

    // Stop the submission when Stop button is clicked
    $('#stop-project-btn').on('click', function() {
        var confirmStop = confirm($(this).data('msg')); // Show confirmation message
        if (!confirmStop) return; // Exit if user cancels

        stopSubmission = true; // Set the stop flag to true
        console.log("Stop button clicked, submission process will stop.");
    });


    // Function to save content of file
    function sendFilesToGPT(event, agent_id) {
        event.preventDefault(); 

        var form = event.target; 
        var formData = new FormData(form);

        
        var submitButton = $(form).find("button[type='submit']"); 
        var originalButtonHTML = submitButton.html(); 

        // Show loading state
        submitButton.prop("disabled", true).html('<i class="fa fa-spinner fa-spin"></i>');
        $(".submit-btn").css("cursor", "not-allowed");
        $(".submit-btn").attr("type", "button"); 

        $.ajax({
            type: 'POST',
            url: "{{ route('api.agents.assign-files') }}",
            data: formData,
            processData: false, 
            contentType: false, 
            success: function(resultData) {
                console.log(resultData);
                // location.reload();
                submitButton.prop("disabled", false).html(originalButtonHTML); 
                $(".submit-btn").css("cursor", "initial");
                $(".submit-btn").attr("type", "submit"); 
                $(`[data-agent-id='${agent_id}']`).trigger("click");

                 // Get the new color class (this example assumes resultData.task_color holds the new color class)
                var newColorClass = 'border-' + resultData.task_color;  // Assuming task_color contains the color name (e.g., 'success')

                // Get the agent ID from the element's ID (assuming the ID is like 'agent-item-1')
                var agentId = resultData.agent_id;  // Assuming agent_id is in the response

                // Get the list item with the matching agent ID
                var agentItem = $('#agent-item-' + agentId);

                // Remove the old border class (we need to target all border-* classes)
                agentItem.removeClass(function(index, className) {
                    return (className.match(/(^|\s)border-\S+/g) || []).join(' ');
                });

                // Add the new border class
                agentItem.addClass(newColorClass);

                // Check if the response indicates to "run again"
                if (resultData.run_status === 'run_again') {
                    // Trigger the submit button click again
                    $(form).submit();
                } else {
                    // pushNotification(resultData.status, resultData.message, resultData.status);
                }
                pushNotification(resultData.status, resultData.message, resultData.status);
            },
            error: function(error) {
                pushNotification('Error', error.error, 'error');
            }
        });
    }
    // let editor;

    // $(document).ready(function() {

    //     // Load Monaco Editor
    //     require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.33.0/min/vs' } });
    //     require(['vs/editor/editor.main'], function() {
    //         monaco.editor.defineTheme('default', {
    //             base: 'vs-dark',
    //             inherit: true,
    //             rules: [
    //                 { token: "identifier", foreground: "9CDCFE" },
    //                 { token: "identifier.function", foreground: "DCDCAA" },
    //                 { token: "type", foreground: "1AAFB0" }
    //             ],
    //             colors: {}
    //         });
    //         monaco.editor.setTheme('default');

    //         // Create the Monaco editor in the designated element
    //         editor = monaco.editor.create(document.getElementById('editor'), {
    //             value: '',
    //             language: 'php'
    //         });

    //         // Add content change listener
    //         editor.onDidChangeModelContent(updateCounts);

    //         function updateCounts() {
    //             const content = editor.getValue();
    //             const charCount = content.length;
    //             const words = content.split(/\s+/).filter(word => word.length > 0);
    //             const wordCount = words.length;
    //             document.getElementById('proceeded_char_count').textContent = charCount;
    //             document.getElementById('proceeded_word_count').textContent = wordCount;
    //         }
    //     });
    // });
    // Click event for agent name
    $(".agent-name").on("click", function () {
        // Remove 'selected' class from all items
        $(".agent-item").removeClass("selected");
        let agentId = $(this).data("agent-id");
        let registerId = $(this).data("register-id");
        let logContainer = $("#log-container");
        startLoading('in');
        // Add 'selected' class to the clicked item
        $(this).closest(".agent-item").addClass("selected");

        $.ajax({
            url: `/admin/code-register/get-logs/${registerId}?agent_id=${agentId}`,
            type: "GET",
            beforeSend: function () {
                logContainer.html('<p class="text-white">Loading logs...</p>').removeClass("d-none");
            },
            success: function (response) {
                logContainer.html('');
                logContainer.html(response.html);
                startLoading('out');

                setTimeout(() => {
                    // Initialize editor for the first active tab
                    let firstActiveTab = $('.tab-pane.show.active').attr('id');
                    if (firstActiveTab) {
                        let logKey = firstActiveTab.split('-').pop();
                        initilizedEditor(logKey);
                    }
                }, 1000);

                // Ensure editor is initialized before updating content
                // if (editor) {
                //     editor.setValue(response.html); // Set the content
                //     editor.setScrollPosition({ scrollTop: 0 });
                //     console.error("Monaco Editor initialized.");
                // } else {
                //     console.error("Monaco Editor is not initialized.");
                // }
            },
            error: function () {
                logContainer.html('<p class="text-danger">Failed to load logs.</p>');
                startLoading('in');
            }
        });
    });

    // Click event for refresh button
    $("#refresh_data_container").on("click", function () {
        let selectedAgent = $(".agent-item.selected .agent-name"); // Find the selected agent

        if (selectedAgent.length) {
            selectedAgent.trigger("click"); // Trigger the click event on the selected agent
        } else {
            console.warn("No agent selected to refresh logs.");
        }
    });
    
    function startLoading(direction = 'in'){
        if(direction == 'in'){
            $('#loader_container').show();
            $('#data_container').hide();
        }else{
            setTimeout(() => {
                $('#loader_container').hide();
                $('#data_container').show();
            }, 500);
        }
    }
    $(document).ready(function () {
        $("#collapseOne").on("show.bs.collapse", function () {
            $("#accordionIcon").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        }).on("hide.bs.collapse", function () {
            $("#accordionIcon").removeClass("fa-chevron-up").addClass("fa-chevron-down");
        });
    });

    // Update Code Register Status
    function updateLogStatus(data) {
        $.ajax({
            type: 'GET',
            url: "{{ route('panel.admin.code-register.update-status') }}",
            data: data,
            success: function(resultData) {
                pushNotification(resultData.status, resultData.message, resultData.status);
                location.reload();
            },
            error: function(error) {
                pushNotification('Error', error.error, 'error');
            }
        });
    }
    $(document).on('change', '#status', function(){
        var status = $(this).val();
        var id = $(this).data('id');
        var data = {
            'id': id,
            'status': status
        };
        updateLogStatus(data)
    });
</script>
