<ul class="text-muted list-unstyled" id="agent_container">
    @foreach ($agents as $key => $agent)
        <form id="agent-form-{{ $key }}" onsubmit="savePrompt(event, {{ $agent->id }})">
            <input type="hidden" name="code_register_id" value="{{ $projectEntity->id }}" id="">
            <input type="hidden" name="agent_id" value="{{ $agent->id }}" id="">
            <input type="hidden" name="project_id" value="{{ $projectEntity->project->id }}" id="">
            <li class="fw-800">
                <a title="{{ $agent->name }}" href="javascript:void(0)"
                    onclick="toggleAccordion({{ $key }})"
                    class="text-white fw-700 d-flex align-items-center"
                    data-toggle="tooltip">
                    {{ Str::limit($agent->name,30) }}<span class="text-{{ @App\Models\CodeRegisterAgent::STATUSES[$agent->status]['color'] }} ml-1 fs-15 fw-800">{{ @App\Models\CodeRegisterAgent::STATUSES[$agent->status]['label'] }}</span>
                    <span id="arrow-{{ $key }}" class="ml-2">
                        {!! '&#9654;' !!} <!-- Right (Closed) Arrow -->
                    </span>
                </a>

                <div id="accordion-{{ $key }}" class="accordion mt-2 collapse">
                    <div class="card bg-dark text-white mb-2">
                        @if($agent->codeRegisterAgentLogs->count() > 0)
                        <div class="d-flex justify-content-between p-2">
                            <span class="text-{{ @App\Models\CodeRegisterAgent::STATUSES[$agent->status]['color'] }} ml-1 fs-15 fw-800">{{ @App\Models\CodeRegisterAgent::STATUSES[$agent->status]['label'] }}</span>
                            <p class="mb-0"><a target="_blank" href="{{ route('panel.admin.code-register.playground',$projectEntity->id)}}?agent_id={{ $agent->id }}" class="btn btn-secondary">Logs <i class="ik ik-external"></i> </a></p>
                        </div>
                        @endif
                        <div class="card-header p-2" id="heading-{{ $key }}">
                            <div class="card-body p-0">
                                @if($agent->scope_ids && is_array($agent->scope_ids))
                                <p class="mb-1">
                                    Scopes:
                                    @foreach($agent->scope_ids as $key => $scope_access_id)
                                    {{ getCategoryById($scope_access_id) ? getCategoryById($scope_access_id)->name : '' }}@if(!$loop->last), @endif
                                    @endforeach
                                </p>
                                @endif
                                @if($agent->gpt_code)
                                <p class="mb-1">
                                    GPT Code: {{ $agent->gpt_code }}
                                </p>
                                @endif
                                @if($agent->model)
                                <p class="mb-1">
                                    Model: {{ $agent->model ? $agent->model->name : '' }}
                                </p>
                                @endif
                                @if($agent->model)
                                <p class="mb-1">
                                    Thread: {{ $agent->thread_id ?? '' }}
                                </p>
                                @endif
                                <textarea name="prompt" id="prompt-{{ $key }}" class="form-control mt-2" 
                                @if($agent->status != App\Models\CodeRegisterAgent::STATUS_NOT_STARTED)
                                readonly @endif rows="18">{{ $agent->prompt }}</textarea>
                            </div>
                        </div>
                        <div class="card-footer p-2 mb-2">
                            @if($agent->status == App\Models\CodeRegisterAgent::STATUS_SCHEDULED)
                                <a href="{{ route('api.run-agent-step2',[$projectEntity->id,$agent->id]) }}" class="btn btn-primary w-100">
                                    Assign Task <i class="ik ik-play"></i>
                                </a>
                            @elseif($agent->status == App\Models\CodeRegisterAgent::STATUS_RUNNING)
                                <a href="{{ route('api.run-agent-step3',[$projectEntity->id,$agent->id]) }}" class="btn btn-primary w-100">
                                    Check Status <i class="ik ik-play"></i>
                                </a>
                            @elseif($agent->status == App\Models\CodeRegisterAgent::STATUS_COMPLETED)
                                <!-- <button type="submit" class="btn btn-primary w-100">
                                    Re-Run <i class="ik ik-play"></i>
                                </button> -->
                            @else
                                <button type="submit" class="btn btn-primary w-100 ajax-btn">
                                    Run <i class="ik ik-play"></i>
                                </button>
                            @endif
                        </div>
                    </div>
                </div>
            </li>
        </form>
    @endforeach
</ul>
