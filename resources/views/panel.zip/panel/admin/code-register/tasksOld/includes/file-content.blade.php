<div class="card mb-0 bg-black border-none" id="data_container">
    <div class="card-header d-flex justify-content-between py-1 px-2 bg-black" style="border-bottom: 1px solid #ccc !important">
        <div> 
            <h2 id="chat-user" class="mb-0 text-white fw-800 ml-2" style=" color: white !important; font-size:14px;">
                {{ $projectEntity->getPrefix() }} Logs
            </h2>
            <div class="fw-700" style="color: #a4aeb6 !important;">
                <span id="file_name" style="display: none;">{{ $agents[0]->model->name ?? '' }}</span>
            </div>
        </div> 
        <div class="d-flex">
            <a class="btn btn-dark btn-secondary ml-2 mb-1 text-danger confirm"
            href="{{ route('api.clear-progress' , $projectEntity->id) }}">Clear
            <div class="fa fa-undo"></div></a>
        </div>
    </div>
           
    <div class="card-body">

        <div id="group_chat_list">
            <div class="card-body chat-box pt-0 pl-0">
                @include('panel.admin.code-register.tasks.includes.file-logs')
            </div>
        </div>
    </div>
</div>