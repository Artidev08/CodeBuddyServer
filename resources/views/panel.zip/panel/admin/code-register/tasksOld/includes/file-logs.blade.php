<ul class="text-muted list-unstyled">
    @if($files->count() > 0)
        @foreach ($files as $file_key => $file)
            <li class="fw-800">
                <a title="{{ $file->file_name }}" href="javascript:void(0)" 
                    onclick="toggleLogsAccordion({{ $file_key }})" 
                    class="text-white fw-700 d-flex align-items-center" 
                    data-toggle="tooltip">
                    {{ $file->getPrefix() }}  
                    ({{ $file->codeRegisterAgent->name ?? '' }} )
                    <span class="text-{{ @App\Models\CodeRegisterAgentLog::STATUSES[$file->status]['color'] }} ml-1 fs-15 fw-800">{{ @App\Models\CodeRegisterAgentLog::STATUSES[$file->status]['label'] }}</span>
                    <span id="logs-arrow-{{ $file_key }}" class="ml-2">
                        {!! '&#9654;' !!} <!-- Right (Closed) Arrow -->
                    </span>
                </a>

                <div id="logs-accordion-{{ $file_key }}" class="logs-accordion mt-2 collapse" style="height: 70vh; overflow:auto;">
                    <div class="card bg-dark text-white mb-2">
                        <div class="card-header p-2" id="heading-{{ $file_key }}">
                            <div class="row">
                                <div class="col-12">
                                    Prompt: {!! nl2br($file->prompt) !!}
                                </div>
                                <hr>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <div class="card-body p-0">
                                        <div class="d-flex justify-content-between">
                                            Input
                                            <div>
                                                <a href="javascript:void(0)"  onclick="copyFileContent('input-prompt-{{ $file_key }}')" id="copyFileContent-{{ $file_key }}" class="btn btn-link text-white px-1 py-1 ml-1"><i class="fa fa-copy"></i> </a>
                                            </div>
                                        </div>
                                        <textarea id="input-prompt-{{ $file_key }}" class="form-control mt-2" rows="18" readonly>{{ $file->input_content }}</textarea>
                                    </div>
                                </div>
                                @if($file->status == App\Models\CodeRegisterAgentLog::STATUS_READY)
                                <div class="col-6">
                                    <div class="card-body p-0">
                                        <div class="d-flex justify-content-between">
                                            Output
                                            <div>
                                                <a href="javascript:void(0)" onclick="copyFileContent('output-prompt-{{ $file_key }}')" id="copyFileContent-{{ $file_key }}" class="btn btn-link text-white px-1 py-1 ml-1"><i class="fa fa-copy"></i> </a>
                                                <a href="javascript:void(0)" onclick="saveFileContent('{{ $file_key }}')"  id="save_file-{{ $file_key }}"  class="btn btn-link text-white px-1 py-1"> <i class="fa fa-save"></i>  </a>
                                            </div>
                                        </div>
                                        <input type="hidden" name="output-path-{{ $file_key }}"  id="output-path-{{ $file_key }}" value="{{ $file->path }}">
                                        <textarea id="output-prompt-{{ $file_key }}" class="form-control mt-2" rows="18">{{ $file->output_content }}</textarea>
                                    </div>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </li>
        @endforeach
    @else
        <div class="loader-img-position" style="top: 30vh; position: relative;left: 50%;">
            <div class="text-white">
                <img src="{{ asset('panel/admin/default/loading.gif') }}" alt=""style="width: 55px;filter:invert(1)">
            </div>
            <p>No Logs!</p>
        </div>
    @endif
</ul>
<!-- Include diff-match-patch Library -->

