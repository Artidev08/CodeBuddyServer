@extends('layouts.main')
@section('title', 'Folders')
@section('content')
@push('head')
    <style>
        .wrapper .page-wrap .main-content {
            padding: 70px 0px 10px 10px;
            margin-top: 0px;
        }
        .form-control:disabled, .form-control[readonly] {
            background-color: #383a3c;
        }
        .entity-select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background: #171719;
            color: white !important;
            border: none;
            border-radius: 0;
            border-bottom: 1px solid #ffffff;
            width: 150px;
            font-size: 15px;
            padding: 10px 40px 10px 20px;
            position: relative;
        }
        footer.footer {
            display: none;
        }
        .app-sidebar.colored {
            display: none;
        }
        .wrapper .header-top {
            padding-left: 10px;
        }
        button#navbar-fullscreen {
            display: none;
        }
        a.nav-link.bg-gray.ml-1 {
            display: none;
        }
        #editor {
            width: 100%;
            height: 58vh;
        }
        .bg-black{
            background-color: #000000 !important;
        }

        .border-none{
            border-radius: 0;
            border: none;
        }

        .h-0{
            height: 0px !important;
        }

        .card .card-header {
            border-bottom: none !important;
        }

        .card .chat-box .chat-list .chat-item.odd .chat-content .box{
            background: #343a40 !important; 
        }

        .card .chat-box .chat-list .chat-item .chat-content .box {
            padding: 10px;
            color: #ffffff;
            background: #000000;
            font-weight: 700;
        }

        .card .card-footer {
            border-top: unset !important;
        }
        .project-card-scroll{
            height: 78vh;
            overflow-y: scroll;
        }
        /* width */
        .project-card-scroll::-webkit-scrollbar {
           width: 2px;
        }
        .split {
            display: flex;
            flex-direction: row;
        }

        .gutter {
            background-color: #eee;
            background-repeat: no-repeat;
            background-position: 50%;
        }

        .gutter.gutter-horizontal {
            background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAeCAYAAADkftS9AAAAIklEQVQoU2M4c+bMfxAGAgYYmwGrIIiDjrELjpo5aiZeMwF+yNnOs5KSvgAAAABJRU5ErkJggg==');
            cursor: col-resize;
            width: 3px !important;
        }
    </style>
      <style>
        body, html { height: 100%; margin: 0; overflow: hidden; }
        #split-0, #split-1 { height: 100%; }
        #editor { width: 100%; height: 100%; }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.33.0/min/vs/loader.min.js"></script>
@endpush
<div class="container-fluid">
    <div class="row mt-10 split">

        <div id="split-0" style="width: 25%;">
            <div class="card mb-0">
                <div class="card-header d-flex justify-content-between py-0 px-2 bg-black" style="border-bottom: 1px solid #ccc !important">
                    <div> 
                        <i class="fa fa-search text-muted"></i>
                    </div>
                    <input class="form-control fw-700 bg-black border-none " type="text" name=""
                        placeholder="Search Agents" id="file-search"
                        oninput="fileSearch()" style="margin-bottom: 7px;">
                    <div class="d-flex">
                        <a target="_blank" title="Sync Agents" href="{{ route('panel.admin.code-register.sync-agents',$projectEntity->id)}}" data-msg="You want to Sync All Agents" class="btn btn-dark btn-secondary text-white ml-2 mb-1 confirm">
                            <i class="fas fa-sync"></i> Sync
                        </a>
                    </div>
                </div>
                
                <div class="card-body border-none px-0 pl-1 bg-black project-card-scroll">
                    <div id="search-file-navigation" class="navigation-main">
                    </div>
                    <div id="main-file-navigation">
                        @include('panel.admin.code-register.tasks.includes.directory-list',['projectEntity' => $projectEntity])
                    </div>
                </div>
            </div>
        </div>

        
        <div id="split-1" style="width: 75%;">
            <div id="loader_container" style="display: none;">
                <div class="loader-img-position" style="top: 30vh; position: relative;left: 50%;">
                    <div class="text-white">
                        <img src="{{ asset('panel/admin/default/loading.gif') }}" alt=""style="width: 55px;filter:invert(1)">
                    </div>
                </div>
            </div>

            @include('panel.admin.code-register.tasks.includes.file-content')
        </div>
    </div>
</div>
<!-- push external js -->
@push('script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/diff-match-patch/20121119/diff_match_patch.js"></script>

    @include('panel.admin.code-register.tasks.includes.script')
@endpush
@endsection


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Text Diff Checker</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/diff@5.0.0/dist/diff.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        .editable {
            width: 100%;
            min-height: 100px;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
            white-space: pre-wrap;
            background-color: #f9f9f9;
        }

        .added {
            background-color: lightgreen;
            color: darkgreen;
        }

        .removed {
            background-color: lightcoral;
            color: darkred;
            text-decoration: line-through;
        }

        .unchanged {
            color: black;
        }

        button {
            margin-top: 10px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <h1>Text Diff Checker</h1>
    <div id="inputText" class="editable" contenteditable="true" placeholder="Enter original text here">arti</div><br>
    <div id="outputText" class="editable" contenteditable="true" placeholder="Enter modified text here">artig</div><br>
    <button id="compareButton">Compare</button>

    <script>
        $(document).ready(function() {
            $('#compareButton').click(function() {
                var inputText = $('#inputText').text();
                var outputText = $('#outputText').text();
                
                // Use diff.js to get the character-by-character differences
                var diff = Diff.diffChars(inputText, outputText);
                
                var resultInput = '';
                var resultOutput = '';
                
                // Process the differences for input and output
                diff.forEach(function(part) {
                    if (part.added) {
                        resultOutput += `<span class="added">${part.value}</span>`;
                    } else if (part.removed) {
                        resultInput += `<span class="removed">${part.value}</span>`;
                    } else {
                        resultInput += `<span class="unchanged">${part.value}</span>`;
                        resultOutput += `<span class="unchanged">${part.value}</span>`;
                    }
                });

                // Apply the highlighted differences
                $('#inputText').html(resultInput);
                $('#outputText').html(resultOutput);
            });
        });
    </script>

</body>
</html>
